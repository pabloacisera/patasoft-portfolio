-- AlterEnum
ALTER TYPE "SubscriptionPlan" ADD VALUE 'TEST';
